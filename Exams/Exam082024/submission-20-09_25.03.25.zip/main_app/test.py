m = 0
if m is not None:
    print('None')