# from django.db.models import Count
#
# def get_tournaments_by_surface_type(surface=None):
#     if not surface:
#         return ""
#
#     tournaments = (Tournament.objects
#                    .annotate(num_matches=Count('matches_tournament'))
#                    .filter(surface_type__icontains=surface)
#                    .order_by('-start_date'))
#
#     if not tournaments.exists():
#         return ""
#
#     return '\n'.join(f"Tournament: {t.name}, start date: {t.start_date}, matches: {t.num_matches}"
#                      for t in tournaments)
#
#
# def get_latest_match_info():
#     latest_match = Match.objects.order_by('-date_played', '-id').first()
#
#     if not latest_match:
#         return ""
#
#     # Get and sort players' names
#     player_names = sorted(list(latest_match.players.values_list('full_name', flat=True)))
#     players_str = " vs ".join(player_names)
#
#     # Handle winner name (if None, return "TBA")
#     winner_name = latest_match.winner.full_name if latest_match.winner else "TBA"
#
#     return (f"Latest match played on: {latest_match.date_played}, "
#             f"tournament: {latest_match.tournament.name}, "
#             f"score: {latest_match.score}, "
#             f"players: {players_str}, "
#             f"winner: {winner_name}, "
#             f"summary: {latest_match.summary}")
#
#
# def get_matches_by_tournament(tournament_name=None):
#     if not tournament_name:
#         return "No matches found."
#
#     tournament = Tournament.objects.filter(name=tournament_name).first()
#     if not tournament:
#         return "No matches found."
#
#     matches = Match.objects.filter(tournament=tournament).order_by('-date_played')
#
#     if not matches.exists():
#         return "No matches found."
#
#     return '\n'.join(f"Match played on: {m.date_played}, score: {m.score}, winner: {m.winner.full_name if m.winner else 'TBA'}"
#                      for m in matches)
