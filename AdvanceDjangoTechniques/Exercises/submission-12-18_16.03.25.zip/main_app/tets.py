


a = 80 < 80

print(a)